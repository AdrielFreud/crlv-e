<?php
	$placa = strtoupper($_POST['placa']);
	$renavam = $_POST['renavam'];
	$cpf = $_POST['cpf'];

	$url = "https://internet.detrannet.mt.gov.br/ApiRenavam/api/CRLV?Placa={$placa}&Renavam={$renavam}&DocumentoProprietario={$cpf}";
	header("Location: {$url}");
?>